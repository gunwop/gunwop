from pico2d import *
import sys
import game_framework

STAND_STATE = 4
WALK_STATE = 3
ATTACK_STATE = 2
DAMAGE_STATE = 1
DEATH_STATE = 0


STATE_LEFT  = 0
STATE_RIGHT = 1
STATE_UP    = 2
STATE_DOWN  = 3
STATE_LU    = 4
STATE_LD    = 5
STATE_RU    = 6
STATE_RD    = 7
