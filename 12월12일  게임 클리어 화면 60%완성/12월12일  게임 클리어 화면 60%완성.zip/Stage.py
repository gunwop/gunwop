from pico2d import *
import random
from Import import *
from sdl2 import *

class Stage:
    TIME_PER_ACTION = 0.4
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    def __init__(self):
        self.image = load_image('Texture/map2.png')
        self.read = load_image('Texture/stone.png')
        self.x, self.y = 550, 350
        self.canvas_width = get_canvas_width()
        self.canvas_height = get_canvas_height()
        self.w = self.image.w
        self.h = self.image.h
        self.state = 0
        self.ilast = 5
        self.total = 0.0
    def set_center_object(self, boy):
        self.center_object = boy
        pass

    def draw(self):
        self.image.clip_draw_to_origin(self.left,self.down,self.canvas_width,self.canvas_height,0,0)
        self.read.clip_draw(0, self.state*64, 128, 64 ,self.left2,self.down2)

    def update(self, frame_time):
        self.total += self.ilast * Stage.ACTION_PER_TIME * frame_time
        self.state =int(self.total) % self.ilast

        self.left = clamp(0, int(self.center_object.x) - self.canvas_width//2, self.w - self.canvas_width)
        self.down = clamp(0, int(self.center_object.y) - self.canvas_height//2, self.h - self.canvas_height)

        self.left2 = self.x - self.left
        self.down2 = self.y - self.down

    def handle_event(self, event):
        pass





class Hurdle:
    read = None
    trees = None
    PIXEL_PER_METER = (10.0 / 0.2)           # 10 pixel 30 cm
    RUN_SPEED_KMPH = 10.0                    # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    def __init__(self):
        self.x, self.y = 1110, 450
        self.count = 1
        if(Hurdle.read == None):
            self.image = load_image('Texture/hurdle.png')

        Hurdle.trees = [Tree() for i in range(5)]

        Hurdle.trees[0].x = 400
        Hurdle.trees[0].y = 400
        Hurdle.trees[1].x = 700
        Hurdle.trees[1].y = 400
        Hurdle.trees[2].x = 500
        Hurdle.trees[2].y = 300
        Hurdle.trees[3].x = 200
        Hurdle.trees[3].y = 100
        Hurdle.trees[4].x = 700
        Hurdle.trees[4].y = 600



    def update(self, frame_time, background, player):
        self.left = self.x - background.left
        self.down = self.y - background.down

        for tree in Hurdle.trees:
            tree.update(frame_time,background,player)

        if(self.collide(player) or self.collide2(player)):
                self.count = 100
        else:
            self.count = 1

        if(self.MyIntersectRect(player)):
            self.pushrect(player)
        if(self.MyIntersectRect2(player)):
            self.pushrect2(player)
        if(self.MyIntersectRect3(player)):
            self.pushrect3(player)
        if(self.MyIntersectRect4(player)):
            self.pushrect4(player)
        if(self.MyIntersectRect5(player)):
            self.pushrect5(player)

    def draw(self):
        self.image.opacify(self.count)
        self.image.draw(self.left, self.down)
        #self.draw_bb()

        for tree in Hurdle.trees:
            tree.draw()

    def draw_bb(self):
        draw_rectangle(*self.get_bb())#제일 오른쪽
        draw_rectangle(*self.get_cc())#반투명
        draw_rectangle(*self.get_dd())#상단 장애물
        draw_rectangle(*self.get_ee())
        draw_rectangle(*self.get_ff())
        draw_rectangle(*self.get_gg())
        draw_rectangle(*self.get_hh())
    def get_bb(self):
        return self.left + 70, self.down - 1000, self.left + 90, self.down + 1000

    def get_cc(self):
        return self.left-60, self.down - 320, self.left +70, self.down - 70

    def get_dd(self):
        return self.left-1200, self.down +300, self.left - 430, self.down + 500

    def get_ee(self):
        return self.left-1200, self.down +250, self.left - 510, self.down +300

    def get_ff(self):
        return self.left - 1200, self.down + 200, self.left - 680, self.down + 250

    def get_gg(self):
        return self.left - 1200, self.down + 130, self.left - 880, self.down + 200

    def get_hh(self):
        return self.left - 1200, self.down + 70, self.left - 970, self.down+130

    def pushrect5(self,player):
        self.garo = self.nright - self.nleft
        self.sero = self.ntop - self.nbottom
        left_a, bottom_a, right_a, top_a = self.get_hh() #자기자신
        left_b, bottom_b, right_b, top_b = player.get_bb() #플레이어
        if(self.garo > self.sero): #위아래체크
            if(self.ntop == top_a):#위애서 충돌
                player.y += player.distance
            elif(self.nbottom == bottom_a):#아래서 충돌
                player.y -=player.distance
        else:
            if(self.nleft == left_a):#좌에서 충돌
                player.x -=player.distance
            elif(self.nright == right_a):
                player.x +=player.distance

    def MyIntersectRect5(self, b):
        self.Vertical = False #수직충돌
        self.Horizon = False #수평충돌
        self.nleft, self.ntop, self.nbottom, self.nright =0,0,0,0
        left_a, bottom_a, right_a, top_a = self.get_hh() #자기자신
        left_b, bottom_b, right_b, top_b = b.get_bb() #플레이어
        #수평충돌
        if(left_a < right_b and right_a > left_b):
            self.Horizon = True
            if(left_a > left_b):
                self.nleft = left_a
            else:
                self.nleft = left_b
            if(right_a < right_b):
                self.nright = right_a
            else:
                self.nright = right_b

        #수직충돌
        if(top_a > bottom_b and  bottom_a < top_b):
            self.Vertical = True

            if(top_a > top_b):
                self.ntop = top_b
            else:
                self.ntop = top_a

            if(bottom_a > bottom_b):
                self.nbottom = bottom_a
            else:
                self.nbottom = bottom_b

        if(self.Horizon== True and self.Vertical == True):
            return True;

        if(self.nleft==0 and self.nright==0 and self.ntop== 0 and self.nbottom == 0):
            return False;


    def pushrect3(self,player):
        self.garo = self.nright - self.nleft
        self.sero = self.ntop - self.nbottom
        left_a, bottom_a, right_a, top_a = self.get_ff() #자기자신
        left_b, bottom_b, right_b, top_b = player.get_bb() #플레이어
        if(self.garo > self.sero): #위아래체크
            if(self.ntop == top_a):#위애서 충돌
                player.y += player.distance
            elif(self.nbottom == bottom_a):#아래서 충돌
                player.y -=player.distance
        else:
            if(self.nleft == left_a):#좌에서 충돌
                player.x -=player.distance
            elif(self.nright == right_a):
                player.x +=player.distance

    def MyIntersectRect3(self, b):
        self.Vertical = False #수직충돌
        self.Horizon = False #수평충돌
        self.nleft, self.ntop, self.nbottom, self.nright =0,0,0,0
        left_a, bottom_a, right_a, top_a = self.get_ff() #자기자신
        left_b, bottom_b, right_b, top_b = b.get_bb() #플레이어
        #수평충돌
        if(left_a < right_b and right_a > left_b):
            self.Horizon = True
            if(left_a > left_b):
                self.nleft = left_a
            else:
                self.nleft = left_b
            if(right_a < right_b):
                self.nright = right_a
            else:
                self.nright = right_b

        #수직충돌
        if(top_a > bottom_b and  bottom_a < top_b):
            self.Vertical = True

            if(top_a > top_b):
                self.ntop = top_b
            else:
                self.ntop = top_a

            if(bottom_a > bottom_b):
                self.nbottom = bottom_a
            else:
                self.nbottom = bottom_b

        if(self.Horizon== True and self.Vertical == True):
            return True;

        if(self.nleft==0 and self.nright==0 and self.ntop== 0 and self.nbottom == 0):
            return False;


    def pushrect4(self,player):
        self.garo = self.nright - self.nleft
        self.sero = self.ntop - self.nbottom
        left_a, bottom_a, right_a, top_a = self.get_gg() #자기자신
        left_b, bottom_b, right_b, top_b = player.get_bb() #플레이어
        if(self.garo > self.sero): #위아래체크
            if(self.ntop == top_a):#위애서 충돌
                player.y += player.distance
            elif(self.nbottom == bottom_a):#아래서 충돌
                player.y -=player.distance
        else:
            if(self.nleft == left_a):#좌에서 충돌
                player.x -=player.distance
            elif(self.nright == right_a):
                player.x +=player.distance

    def MyIntersectRect4(self, b):
        self.Vertical = False #수직충돌
        self.Horizon = False #수평충돌
        self.nleft, self.ntop, self.nbottom, self.nright =0,0,0,0
        left_a, bottom_a, right_a, top_a = self.get_gg() #자기자신
        left_b, bottom_b, right_b, top_b = b.get_bb() #플레이어
        #수평충돌
        if(left_a < right_b and right_a > left_b):
            self.Horizon = True
            if(left_a > left_b):
                self.nleft = left_a
            else:
                self.nleft = left_b
            if(right_a < right_b):
                self.nright = right_a
            else:
                self.nright = right_b

        #수직충돌
        if(top_a > bottom_b and  bottom_a < top_b):
            self.Vertical = True

            if(top_a > top_b):
                self.ntop = top_b
            else:
                self.ntop = top_a

            if(bottom_a > bottom_b):
                self.nbottom = bottom_a
            else:
                self.nbottom = bottom_b

        if(self.Horizon== True and self.Vertical == True):
            return True;

        if(self.nleft==0 and self.nright==0 and self.ntop== 0 and self.nbottom == 0):
            return False;


    def pushrect(self,player):
        self.garo = self.nright - self.nleft
        self.sero = self.ntop - self.nbottom
        left_a, bottom_a, right_a, top_a = self.get_dd() #자기자신
        left_b, bottom_b, right_b, top_b = player.get_bb() #플레이어
        if(self.garo > self.sero): #위아래체크
            if(self.ntop == top_a):#위애서 충돌
                player.y += player.distance
            elif(self.nbottom == bottom_a):#아래서 충돌
                player.y -=player.distance
        else:
            if(self.nleft == left_a):#좌에서 충돌
                player.x -=player.distance
            elif(self.nright == right_a):
                player.x +=player.distance

    def MyIntersectRect(self, b):
        self.Vertical = False #수직충돌
        self.Horizon = False #수평충돌
        self.nleft, self.ntop, self.nbottom, self.nright =0,0,0,0
        left_a, bottom_a, right_a, top_a = self.get_dd() #자기자신
        left_b, bottom_b, right_b, top_b = b.get_bb() #플레이어
        #수평충돌
        if(left_a < right_b and right_a > left_b):
            self.Horizon = True
            if(left_a > left_b):
                self.nleft = left_a
            else:
                self.nleft = left_b
            if(right_a < right_b):
                self.nright = right_a
            else:
                self.nright = right_b

        #수직충돌
        if(top_a > bottom_b and  bottom_a < top_b):
            self.Vertical = True

            if(top_a > top_b):
                self.ntop = top_b
            else:
                self.ntop = top_a

            if(bottom_a > bottom_b):
                self.nbottom = bottom_a
            else:
                self.nbottom = bottom_b

        if(self.Horizon== True and self.Vertical == True):
            return True;

        if(self.nleft==0 and self.nright==0 and self.ntop== 0 and self.nbottom == 0):
            return False;



    def pushrect2(self,player):
        self.garo = self.nright - self.nleft
        self.sero = self.ntop - self.nbottom
        left_a, bottom_a, right_a, top_a = self.get_ee() #자기자신
        left_b, bottom_b, right_b, top_b = player.get_bb() #플레이어
        if(self.garo > self.sero): #위아래체크
            if(self.ntop == top_a):#위애서 충돌
                player.y += player.distance
            elif(self.nbottom == bottom_a):#아래서 충돌
                player.y -=player.distance
        else:
            if(self.nleft == left_a):#좌에서 충돌
                player.x -=player.distance
            elif(self.nright == right_a):
                player.x +=player.distance

    def MyIntersectRect2(self, b):
        self.Vertical = False #수직충돌
        self.Horizon = False #수평충돌
        self.nleft, self.ntop, self.nbottom, self.nright =0,0,0,0
        left_a, bottom_a, right_a, top_a = self.get_ee() #자기자신
        left_b, bottom_b, right_b, top_b = b.get_bb() #플레이어
        #수평충돌
        if(left_a < right_b and right_a > left_b):
            self.Horizon = True
            if(left_a > left_b):
                self.nleft = left_a
            else:
                self.nleft = left_b
            if(right_a < right_b):
                self.nright = right_a
            else:
                self.nright = right_b

        #수직충돌
        if(top_a > bottom_b and  bottom_a < top_b):
            self.Vertical = True

            if(top_a > top_b):
                self.ntop = top_b
            else:
                self.ntop = top_a

            if(bottom_a > bottom_b):
                self.nbottom = bottom_a
            else:
                self.nbottom = bottom_b

        if(self.Horizon== True and self.Vertical == True):
            return True;

        if(self.nleft==0 and self.nright==0 and self.ntop== 0 and self.nbottom == 0):
            return False;





    def collide2(a, b):
        # fill here
        left_a, bottom_a, right_a, top_a = a.get_cc()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_a > right_b : return False
        if right_a < left_b : return False
        if top_a < bottom_b : return False
        if bottom_a > top_b : return False
        return True
        pass

    def collide(a, b):
        # fill here
        left_a, bottom_a, right_a, top_a = a.get_bb()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_a > right_b : return False
        if right_a < left_b : return False
        if top_a < bottom_b : return False
        if bottom_a > top_b : return False

        return True
        pass

    def collide3(a, b):
        # fill here
        left_a, bottom_a, right_a, top_a = a.get_dd()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_a > right_b : return False
        if right_a < left_b : return False
        if top_a < bottom_b : return False
        if bottom_a > top_b : return False

        return True
        pass


class Tree:
    read = None
    def __init__(self):
        self.x, self.y = 0, 0
        if(Tree.read == None):
            self.image = load_image('Texture/tree.png')

    def update(self, frame_time, background, player):
        self.left = self.x - background.left
        self.down = self.y - background.down

        if(self.MyIntersectRect(player)):
            self.pushrect(player)


    def draw(self):
        self.image.draw(self.left, self.down)
        #self.draw_bb()

    def draw_bb(self):
        draw_rectangle(*self.get_bb())
        draw_rectangle(*self.get_cc())

    def get_bb(self):
        return self.left - 15, self.down - 70, self.left + 15, self.down - 50

    def get_cc(self):
        return self.nleft, self.nbottom, self.nright, self.ntop


    def pushrect(self,player):
        self.garo = self.nright - self.nleft
        self.sero = self.ntop - self.nbottom
        left_a, bottom_a, right_a, top_a = self.get_bb() #자기자신
        left_b, bottom_b, right_b, top_b = player.get_bb() #플레이어
        if(self.garo > self.sero): #위아래체크
            if(self.ntop == top_a):#위애서 충돌
                player.y += player.distance
            elif(self.nbottom == bottom_a):#아래서 충돌
                player.y -=player.distance
        else:
            if(self.nleft == left_a):#좌에서 충돌
                player.x -=player.distance
            elif(self.nright == right_a):
                player.x +=player.distance

    def MyIntersectRect(self, b):
        self.Vertical = False #수직충돌
        self.Horizon = False #수평충돌
        self.nleft, self.ntop, self.nbottom, self.nright =0,0,0,0
        left_a, bottom_a, right_a, top_a = self.get_bb() #자기자신
        left_b, bottom_b, right_b, top_b = b.get_bb() #플레이어
        #수평충돌
        if(left_a < right_b and right_a > left_b):
            self.Horizon = True


            if(left_a > left_b):
                self.nleft = left_a
            else:
                self.nleft = left_b
            if(right_a < right_b):
                self.nright = right_a
            else:
                self.nright = right_b

        #수직충돌
        if(top_a > bottom_b and  bottom_a < top_b):
            self.Vertical = True


            if(top_a > top_b):
                self.ntop = top_b
            else:
                self.ntop = top_a

            if(bottom_a > bottom_b):
                self.nbottom = bottom_a
            else:
                self.nbottom = bottom_b



        if(self.Horizon== True and self.Vertical == True):
            return True;

        if(self.nleft==0 and self.nright==0 and self.ntop== 0 and self.nbottom == 0):
            return False;



    def collide(a, b):
        # fill here
        left_a, bottom_a, right_a, top_a = a.get_bb()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_a < right_b : return False
        if right_a > left_b : return False
        if top_a < bottom_b : return False
        if bottom_a > top_b : return False

        return True
        pass