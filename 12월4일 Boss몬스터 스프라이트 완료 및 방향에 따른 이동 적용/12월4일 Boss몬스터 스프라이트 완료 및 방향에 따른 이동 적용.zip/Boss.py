from Import import *
from pico2d import *
import math
import random

class Boss:
    read = None
    PIXEL_PER_METER = (10.0 / 0.1)           # 10 pixel 30 cm
    RUN_SPEED_KMPH = random.randint(1, 2)                    # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION

    def __init__(self):
        self.x = 400
        self.y = 400
        self.left = 0.0
        self.down = 0.0
        self.frame = 0
        self.ilast = 0
        self.total = 0.0
        self.damagecheck = False
        self.state = BOSSSTAND_STATE       #상태
        self.dirsheet = STATE_DOWN #방향

    def load_Image(self):
        if Boss.read == None:
            self.boss_down = load_image('Texture/bossdown.png')
            self.boss_ld = load_image('Texture/bossleftdown.png')
            self.boss_left = load_image('Texture/bossleft.png')
            self.boss_lu = load_image('Texture/bossleftup.png')
            self.boss_rd = load_image('Texture/bossrightdown.png')
            self.boss_right = load_image('Texture/bossright.png')
            self.boss_ru = load_image('Texture/bossrightup.png')
            self.boss_up = load_image('Texture/bossup.png')

            self.read = {STATE_DOWN : self.boss_down, STATE_LD : self.boss_ld,
                         STATE_LEFT : self.boss_left, STATE_LU : self.boss_lu,
                         STATE_RD : self.boss_rd, STATE_RIGHT : self.boss_right,
                         STATE_RU : self.boss_ru, STATE_UP : self.boss_up}

    def update(self,frame_time,background):
        self.left = self.x - background.left
        self.down = self.y - background.down
        self.SetMotion()
        self.FrameMove(frame_time)
        self.DirMove(frame_time)


    def FrameMove(self, frame_time):
        Boss.TIME_PER_ACTION = 0.5
        Boss.ACTION_PER_TIME = 1.0 / Boss.TIME_PER_ACTION

        self.total += self.ilast * Boss.ACTION_PER_TIME * frame_time
        self.frame = int(self.total) % self.ilast
        #distance = self.RUN_SPEED_PPS * frame_time

    def draw(self):
        self.read[self.dirsheet].clip_draw(self.frame * 256,  self.state* 256, 256, 256, self.left, self.down)


    def SetMotion(self):
        if(self.state == BOSSSTAND_STATE):
            self.ilast = 4

        if(self.state == BOSSWALK_STATE):
            self.ilast = 8

        if(self.state == BOSSSWING_STATE):
            self.ilast = 4

        if(self.state == BOSSDEFENCE_STATE):
            self.ilast = 2

        if(self.state == BOSSDAMAGE_STATE):
            self.damagecheck = True
            self.ilast = 2

        if(self.state == BOSSDEATH_STATE and self.damagecheck == False):
            self.ilast = 6

    def DirMove(self, frame_time):
        distance = self.RUN_SPEED_PPS *frame_time
        if(self.state == BOSSWALK_STATE):
            if(self.dirsheet == STATE_LEFT):
                self.x -=distance
            elif(self.dirsheet == STATE_RIGHT):
                self.x +=distance
            elif(self.dirsheet == STATE_UP):
                self.y +=distance
            elif(self.dirsheet == STATE_DOWN):
                self.y -=distance
            elif(self.dirsheet == STATE_LU):
                self.x -=distance
                self.y +=distance
            elif(self.dirsheet == STATE_LD):
                self.x -=distance
                self.y -=distance
            elif(self.dirsheet == STATE_RU):
                self.x +=distance
                self.y +=distance
            elif(self.dirsheet == STATE_RD):
                self.x +=distance
                self.y -=distance

