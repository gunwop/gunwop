from pico2d import *

class UI:
    def __init__(self):
        self.hpbar = load_image('Texture/UI/hp.png')
        self.hpgage = load_image('Texture/UI/hpgage.png')
        self.manabar = load_image('Texture/UI/mana.png')
        self.managage = load_image('Texture/UI/managage.png')
        self.health = 0
        self.manahealth = 0
    def draw(self):
        self.hpbar.clip_draw(0,0, 400, 30, 210, 580)
        self.hpgage.clip_draw(0,0, 304-self.health, 15, 210-self.health/2, 580)
        self.manabar.clip_draw(0,0, 350, 30, 208, 550)
        self.managage.clip_draw(0,0, 273-self.manahealth, 10, 208-self.manahealth/2, 549)
