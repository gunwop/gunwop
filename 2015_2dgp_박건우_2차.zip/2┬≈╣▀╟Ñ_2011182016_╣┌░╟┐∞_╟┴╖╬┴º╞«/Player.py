from Import import *
from pico2d import *

class Player:
    read = None

    def __init__(self):
        self.x, self.y = 400, 300
        self.frame = 0
        self.speed = 6
        self.ilast = 0
        self.state = STAND_STATE #player 상태
        self.dirsheet = STATE_DOWN
        self.dirleft = False
        self.dirright = False
        self.dirup = False
        self.dirdown = False

    def load_Image(self):

        if Player.read == None:
             self.player_down = load_image('Texture/player/Player_DOWN.png') #아래방향
             self.player_ld = load_image('Texture/player/Player_LD.png') #왼쪽아래
             self.player_left = load_image('Texture/player/Player_LEFT.png') #왼쪽
             self.player_lu = load_image('Texture/player/Player_LU.png') #왼쪽위
             self.player_rd = load_image('Texture/player/Player_RD.png') #오른쪽아래
             self.player_right = load_image('Texture/player/Player_RIGHT.png') #오른쪽
             self.player_ru = load_image('Texture/player/Player_RU.png') #오른쪽 위
             self.player_up = load_image('Texture/player/Player_UP.png') #위

             self.read = {STATE_DOWN : self.player_down, STATE_LD : self.player_ld,
                            STATE_LEFT : self.player_left, STATE_LU : self.player_lu,
                            STATE_RD : self.player_rd, STATE_RIGHT : self.player_right,
                            STATE_RU : self.player_ru, STATE_UP : self.player_up}

    def update(self):
        self.SetMotion()
        self.frame = (self.frame +1)% self.ilast
        delay(0.05)


    def draw(self):

        self.read[self.dirsheet].clip_draw(self.frame * 200, self.state*200, 200, 200, self.x , self.y)



    def SetMotion(self):
        if(self.state == STAND_STATE): #대기상태
            self.ilast = 4


        if(self.state == WALK_STATE): #걷기상태
            self.ilast = 6
            if self.dirleft == True:
                if self.x > 0:
                    self.x -= self.speed
                else:
                    self.x = 0
            if self.dirright == True:
                if self.x < 800:
                    self.x += self.speed
                else:
                    self.x = 800
            if self.dirup == True:
                if self.y < 600:
                    self.y += self.speed
                else:
                    self.y = 600

            if self.dirdown == True:
                if self.y > 0:
                    self.y -= self.speed
                else:
                    self.y = 0


        if(self.state == ATTACK_STATE): #공격상태
            self. ilast = 6

        if(self.state == DAMAGE_STATE): #피격상태
            self.ilast = 2

        if(self.state == DEATH_STATE): #사망상태
            self.ilast = 4


    def handle_event(self, event):
        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT): #왼쪽keydown
            self.dirsheet = STATE_LEFT
            self.state = WALK_STATE
            self.dirleft = True
            if self.dirleft == True and self.dirup == True:
                self.dirsheet = STATE_LU
            if self.dirleft == True and self.dirdown == True:
                self.dirsheet = STATE_LD



        if(event.type, event.key) == (SDL_KEYUP, SDLK_LEFT): #왼쪽keyup
            self.dirleft = False

            if(self.dirleft == False and self.dirright == False and self.dirup == False and self.dirdown == False):
                self.state = STAND_STATE
                self.dirsheet = STATE_LEFT
            elif self.dirright == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_RIGHT
            elif self.dirup == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_UP
            elif self.dirdown == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_DOWN








        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT): #오른쪽
            self.dirsheet = STATE_RIGHT
            self.state = WALK_STATE
            self.dirright = True
            if self.dirright == True and self.dirup == True:
                self.dirsheet = STATE_RU
            if self.dirright == True and self.dirdown == True:
                self.dirsheet = STATE_RD


        if(event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT): #오른쪽 up
            self.dirright = False

            if(self.dirleft == False and self.dirright == False and self.dirup == False and self.dirdown == False):
                self.state = STAND_STATE
                self.dirsheet = STATE_RIGHT
            elif self.dirleft == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_LEFT
            elif self.dirup == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_UP
            elif self.dirdown == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_DOWN

        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_UP): # 위쪽
            self.dirsheet = STATE_UP
            self.state = WALK_STATE
            self.dirup = True
            if self.dirup == True and self.dirleft == True:
                self.dirsheet = STATE_LU
            if self.dirup == True and self.dirright == True:
                self.dirsheet = STATE_RU


        if(event.type, event.key) == (SDL_KEYUP, SDLK_UP): # 위쪽 up
            self.dirup = False

            if(self.dirleft == False and self.dirright == False and self.dirup == False and self.dirdown == False):
                self.state = STAND_STATE
                self.dirsheet = STATE_UP
            elif self.dirleft == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_LEFT
            elif self.dirright == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_RIGHT
            elif self.dirdown == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_DOWN

            elif self.dirleft == False and self.dirup == False:
                self.dirsheet = STATE_LU

        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_DOWN): #아래쪽
            self.dirsheet = STATE_DOWN
            self.state = WALK_STATE
            self.dirdown = True
            if self.dirdown == True and self.dirleft == True:
                self.dirsheet = STATE_LD
            if self.dirdown == True and self.dirright == True:
                self.dirsheet = STATE_RD

        if(event.type, event.key) == (SDL_KEYUP, SDLK_DOWN): # 아래쪽 up
            self.dirdown = False

            if(self.dirleft == False and self.dirright == False and self.dirup == False and self.dirdown == False):
                self.state = STAND_STATE
                self.dirsheet = STATE_DOWN
            elif self.dirleft == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_LEFT
            elif self.dirright == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_RIGHT
            elif self.dirup == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_UP

        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_a):
                self.state = ATTACK_STATE

        if(event.type, event.key) == (SDL_KEYUP, SDLK_a):
            if(self.dirleft == False and self.dirright == False and self.dirup == False and self.dirdown == False):
                self.state = STAND_STATE

            else:
                self.state = WALK_STATE











