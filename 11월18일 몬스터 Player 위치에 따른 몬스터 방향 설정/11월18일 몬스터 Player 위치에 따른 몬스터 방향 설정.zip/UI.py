from pico2d import *


class UI:
    def __init__(self,player):
        self.hpbar = load_image('Texture/UI/hp.png')
        self.hpgage = load_image('Texture/UI/hpgage.png')
        self.manabar = load_image('Texture/UI/mana.png')
        self.managage = load_image('Texture/UI/managage.png')
        self.health = player.maxHp
        self.manahealth = player.maxmana

    def draw(self):
        self.hpbar.clip_draw(0,0, 400, 30, 210, 580)
        self.hpgage.clip_draw(0,0, 404 - self.health , 15, 260 - self.health/2, 580)
        self.manabar.clip_draw(0,0, 350, 30, 208, 550)
        self.managage.clip_draw(0,0,  373-int(self.manahealth), 10, 258- int(self.manahealth/2), 549) #여기서는373 - 현재mana

    def update(self,player):
        self.health = player.nowHp #현재 player의 hp
        self.manahealth = player.nowmana #현재 player의 mana
