from pico2d import *
import random
from Import import *
from sdl2 import *

class Stage:
    def __init__(self):
        self.image = load_image('Texture/map/map2.png')
        self.canvas_width = get_canvas_width()
        self.canvas_height = get_canvas_height()
        self.w = self.image.w
        self.h = self.image.h

    def set_center_object(self, boy):
        self.center_object = boy
        pass

    def draw(self):
        self.image.clip_draw_to_origin(self.left,self.down,self.canvas_width,self.canvas_height,0,0)

    def update(self, frame_time):

        self.left = clamp(0, int(self.center_object.x) - self.canvas_width//2, self.w - self.canvas_width)
        self.down = clamp(0, int(self.center_object.y) - self.canvas_height//2, self.h - self.canvas_height)

    def handle_event(self, event):
        pass





class Hurdle:
    read = None
    trees = None
    PIXEL_PER_METER = (10.0 / 0.2)           # 10 pixel 30 cm
    RUN_SPEED_KMPH = 10.0                    # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    def __init__(self):
        self.x, self.y = 1110, 450
        self.count = 1
        if(Hurdle.read == None):
            self.image = load_image('Texture/map/hurdle.png')

        Hurdle.trees = [Tree() for i in range(5)]

        Hurdle.trees[0].x += 300
        Hurdle.trees[0].y += 100
        Hurdle.trees[1].x += 200
        Hurdle.trees[2].x += 400
        Hurdle.trees[3].x += 400
        Hurdle.trees[3].y +=200
        Hurdle.trees[4].x = 600
        Hurdle.trees[4].y = 300


    def update(self, frame_time, background, player):
        self.left = self.x - background.left
        self.down = self.y - background.down

        for tree in Hurdle.trees:
            tree.update(frame_time,background,player)

        if(self.collide(player) or self.collide2(player)):
            if(self.left-30 <player.left):
                self.count = 100
        else:
            self.count = 1


    def draw(self):
        self.image.opacify(self.count)
        self.image.draw(self.left, self.down)
        self.draw_bb()

        for tree in Hurdle.trees:
            tree.draw()

    def draw_bb(self):
        draw_rectangle(*self.get_bb())
        draw_rectangle(*self.get_cc())
        draw_rectangle(*self.get_dd())

    def get_bb(self):
        return self.left + 70, self.down - 1000, self.left + 90, self.down + 1000

    def get_cc(self):
        return self.left-60, self.down - 320, self.left +70, self.down - 70

    def get_dd(self):
        return self.left-1200, self.down +260, self.left - 430, self.down + 500


    def collide2(a, b):
        # fill here
        left_a, bottom_a, right_a, top_a = a.get_cc()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_a > right_b : return False
        if right_a < left_b : return False
        if top_a < bottom_b : return False
        if bottom_a > top_b : return False
        return True
        pass

    def collide(a, b):
        # fill here
        left_a, bottom_a, right_a, top_a = a.get_bb()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_a > right_b : return False
        if right_a < left_b : return False
        if top_a < bottom_b : return False
        if bottom_a > top_b : return False

        return True
        pass

    def collide3(a, b):
        # fill here
        left_a, bottom_a, right_a, top_a = a.get_dd()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_a > right_b : return False
        if right_a < left_b : return False
        if top_a < bottom_b : return False
        if bottom_a > top_b : return False

        return True
        pass

class Tree:
    read = None
    def __init__(self):
        self.x, self.y = 300, 400
        self.rx, self.ry, self.rw, self.rh = 0,0,0,0
        if(Tree.read == None):
            self.image = load_image('Texture/map/tree.png')

    def update(self, frame_time, background, player):
        self.left = self.x - background.left
        self.down = self.y - background.down



    def draw(self):
        self.image.draw(self.left, self.down)
        self.draw_bb()

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return self.left - 15, self.down - 70, self.left + 15, self.down - 50


    def collide(a, b):
        # fill here
        left_a, bottom_a, right_a, top_a = a.get_bb()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_a > right_b : return False
        if right_a < left_b : return False
        if top_a < bottom_b : return False
        if bottom_a > top_b : return False

        return True
        pass