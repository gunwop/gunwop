import random
import json
import os
import sys
from pico2d import *
sys.path.append('../LabsAll/Labs')
import gameover
import game_framework
from Import import *

import UI
import Player
import Monster
import Stage
import Skill
name = "MainState"

player = None
hp = None
skill = None
monsters = None
stage = None
hurdle = None
lightingskill = None
monstertime = 0.0

def enter():
    global player
    global stage
    global hp
    global skill
    global monsters
    global hurdle
    global lightingskill


    monsters = [Monster.Monster() for i in range(5)]

    lightingskill = Skill.LightingSkillList()


    player = Player.Player()
    stage = Stage.Stage()
    hurdle = Stage.Hurdle()

    hp = UI.UI(player)
    skill = Player.Skill()
    stage.set_center_object(player)
    player.set_background(stage)

    player.load_Image()
    for monster in monsters:
        monster.load_Image()
    pass


def exit():
    global player
    global stage
    global hp
    global skill
    global monsters
    global hurdle
    global lightingskill

    del(lightingskill)
    del(hurdle)
    del(monsters)
    del(skill)
    del(hp)
    del(stage)
    del(player)
    close_canvas()
    pass


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global player

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        if event.key == SDLK_ESCAPE or event.key == SDLK_q:
            game_framework.quit()
        else:
            player.handle_event(event,frame_time)
            skill.handle_event(event,player)
            lightingskill.handle_event(event,frame_time,player)

    pass



def update(frame_time):
    global monstertime
    monstertime +=frame_time

    lightingskill.update(frame_time,stage, monsters)
    stage.update(frame_time)
    player.update(frame_time)
    hurdle.update(frame_time, stage,player)
    skill.update()
    hp.update(player)

    #if(monstertime >= 10):
    for monster in monsters:
        monster.update(player, frame_time, stage,skill)
        if(monster.timecheck > 1):
            monsters.remove(monster)

    pass


def draw(frame_time):

    stage.draw()
    lightingskill.draw(frame_time)
    skill.draw()
    player.draw(frame_time)
    hp.draw()

    #if(monstertime >= 10):
    for monster in monsters:
        monster.draw(frame_time)

    hurdle.draw()
    update_canvas()
    pass





