from Import import *
from pico2d import *
import random

class LightingSkillList:
    def __init__(self):
        self.skilllist = []
        self.mana = 60
        self.length = 0
    def draw(self,frame_time):
        for skills in self.skilllist:
            skills.draw(frame_time)

    def update(self,frame_time,stage,monsters):
        for skills in self.skilllist:
            if(skills.staytime >= 10):
                self.skilllist.remove(skills)
                self.length -=1
            else:
                skills.update(frame_time,stage)

        if monsters != None:
            for monster in monsters:
                for skills in self.skilllist:
                    if skills.collide(monster):
                        self.skilllist.remove(skills)
                        monster.nowHp -= 50
                        monster.state = MDAMAGE_STATE



    def handle_event(self, event, frame_time,player):
        if(event.type, event.key) == (SDL_KEYDOWN,SDLK_s):
            if(player.nowmana <= 363 and self.length < 5):
                player.nowmana += self.mana
                self.skilllist.append(LightingSkill(player))
                self.length += 1


    def get_bb(self):
        for skills in self.skilllist:
            return skills.left - 10, skills.down - 10, skills.left + 10, skills.down + 10






class LightingSkill:
    read = None
    TIME_PER_ACTION = 0.4
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION

    def __init__(self, player):
        self.x = player.x
        self.y = player.y
        self.frame = 0
        self.mana = 20
        self.ilast = 10
        self.total = 0.0
        self.staytime = 0.0
        self.left  =0.0
        self.down = 0.0
        if LightingSkill.read == None:
            LightingSkill.image = load_image('Texture/Effect/light.png')


    def draw(self,frame_time):
        self.image.clip_draw(self.frame *51,0, 51, 59, self.left, self.down)
        self.draw_bb()


    def update(self,frame_time,stage):
        self.left = self.x - stage.left
        self.down = self.y - stage.down

        LightingSkill.TIME_PER_ACTION = 0.4
        LightingSkill.ACTION_PER_TIME = 1.0 / LightingSkill.TIME_PER_ACTION

        self.total += self.ilast * LightingSkill.ACTION_PER_TIME * frame_time
        self.frame = int(self.total) % self.ilast

        self.staytime +=frame_time

    def get_bb(self):
        return self.left - 10, self.down - 10, self.left + 10, self.down + 10

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def collide(self, b):
        left_self, bottom_self, right_self, top_self = self.get_bb()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_self > right_b : return False
        if right_self < left_b : return False
        if top_self < bottom_b : return False
        if bottom_self > top_b : return False
        return True
