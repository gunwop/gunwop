from Import import *
from pico2d import *



class LightingSkill:
    read = None
    TIME_PER_ACTION = 0.4
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION

    def __init__(self):
        self.x = 500
        self.y = 500
        self.frame = 0
        self.mana = 20
        self.ilast = 10
        self.total = 0.0
        if LightingSkill.read == None:
            LightingSkill.image = load_image('Texture/Effect/light.png')


    def draw(self,frame_time):
            self.image.clip_draw(self.frame *51,0, 51, 59, self.x, self.y)


    def update(self,frame_time,player):
        LightingSkill.TIME_PER_ACTION = 0.4
        LightingSkill.ACTION_PER_TIME = 1.0 / LightingSkill.TIME_PER_ACTION

        self.total += self.ilast * LightingSkill.ACTION_PER_TIME * frame_time
        self.frame = int(self.total) % self.ilast




    def get_bb(self):
        return self.x - 30, self.y - 60, self.x + 20, self.y - 30

    def draw_bb(self):
        draw_rectangle(*self.get_bb())
