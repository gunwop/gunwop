import random
import json
import os
import sys
from pico2d import *
sys.path.append('../LabsAll/Labs')
import gameover
import game_framework
from Import import *

import UI
import Player
import Monster
import Stage
name = "MainState"

player = None
hp = None
skill = None
monster = None
stage = None
hurdle = None
#if(player.x >= 700): 게임 실패시 트리거
#game_framework.push_state(gameover)



def enter():
    global player
    global stage
    global hp
    global skill
    global monster
    global hurdle

    monster = Monster.Monster()
    player = Player.Player()
    stage = Stage.Stage()
    hurdle = Stage.Hurdle()

    hp = UI.UI(player)
    skill = Player.Skill()
    stage.set_center_object(player)
    player.set_background(stage)

    player.load_Image()
    monster.load_Image()

    pass


def exit():
    global player
    global stage
    global hp
    global skill
    global monster
    global hurdle

    del(hurdle)
    del(monster)
    del(skill)
    del(hp)
    del(stage)
    del(player)
    close_canvas()
    pass


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global player
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        if event.key == SDLK_ESCAPE or event.key == SDLK_q:
            game_framework.quit()
        else:
            player.handle_event(event,frame_time)
            skill.handle_event(event,player)
    pass



def update(frame_time):
    stage.update(frame_time)
    player.update(frame_time)
    hurdle.update(frame_time, stage)
    skill.update()
    hp.update(player)
    monster.update(player, frame_time, stage)


    pass


def draw(frame_time):
    stage.draw()
    skill.draw()
    skill.draw_bb()
    player.draw(frame_time)
    player.draw_bb()
    hp.draw()
    monster.draw(frame_time)
    monster.draw_bb()
    hurdle.draw()
    update_canvas()
    pass





