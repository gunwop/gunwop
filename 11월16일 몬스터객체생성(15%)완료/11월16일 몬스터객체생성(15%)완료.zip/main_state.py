import random
import json
import os
import sys
from pico2d import *
sys.path.append('../LabsAll/Labs')

import game_framework
from Import import *

import UI
import Player
import Monster

name = "MainState"
stage = None
player = None
hp = None
skill = None
monster = None

class Stage:
    def __init__(self):
        self.image = load_image('Texture/map/map1.png')
        self.stone = load_image('Texture/Effect/stone.png')
        self.fcx =get_canvas_width()
        self.fcy = get_canvas_height()
        self.x = 0
        self.y = 0
        self.w = self.image.w #1200, 900
        self.h = self.image.h
        self.frame = 4
        self.count = -1



    def set_center_object(self, boy):
        self.center_object = boy
        pass

    def draw(self):
        self.image.clip_draw_to_origin(self.x ,self.y, self.fcx, self.fcy, 0, 0)

        self.stone.clip_draw(0, 64*self.frame , 128, 64, 400 - self.x, 300 - self.y)

    def update(self):
        self.x = clamp(0, int(self.center_object.x - self.fcx/2), self.w - self.fcx) #1200 - 800
        self.y = clamp(0, int(self.center_object.y -self.fcy/2), self.h - self.fcy) #900 - 600

        self.frame = (self.frame + self.count)%4

        if self.frame <=0 or self.frame >=4:
            self.count *= -1
        pass




def enter():
    global player
    global stage
    global hp
    global skill
    global monster

    monster = Monster.Monster()
    player = Player.Player()
    stage = Stage()
    hp = UI.UI(player)
    skill = Player.Skill()

    stage.set_center_object(player)
    player.load_Image()

    pass


def exit():
    global player
    global stage
    global hp
    global skill
    global monster

    del(monster)
    del(skill)
    del(hp)
    del(stage)
    del(player)
    close_canvas()
    pass


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global player
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        if event.key == SDLK_ESCAPE or event.key == SDLK_q:
            game_framework.quit()
        else:
            player.handle_event(event,frame_time)
            skill.handle_event(event,player)
    pass



def update(frame_time):
    player.update(frame_time)
    skill.update()
    stage.update()
    hp.update(player)
    monster.update()
    pass


def draw(frame_time):

    clear_canvas()
    stage.draw()
    skill.draw()
    skill.draw_bb()
    player.draw(frame_time)
    player.draw_bb()
    hp.draw()
    monster.draw()

    update_canvas()
    pass





