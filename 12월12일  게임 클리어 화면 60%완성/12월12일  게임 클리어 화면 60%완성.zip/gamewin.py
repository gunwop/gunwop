import game_framework
from pico2d import *
import title_state
import random
name = "GameWin"
image = None
black = None
count = 0.0
def enter():
    # fill here
    global image
    global black
    image = load_image('Texture/gamewin.png')
    black = load_image('Texture/gameoverblack.png')
    pass

def exit():
    # fill here
    global image
    global black

    del(image)
    del(black)
    close_canvas()
    pass


def pause():
    pass

def resume():
    pass


def handle_events(frame_time):
    # fill here
    global count
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                if(count == 1):
                    game_framework.quit()
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
                if(count == 1):
                    game_framework.push_state(title_state)
    pass


def update(frame_time):
    global count
    if(count < 1):
        count += frame_time
    else:
        count = 1

def draw(frame_time):
    # fill here
    global image
    global black
    global count

    clear_canvas()
    black.draw(400, 300)
    image.opacify(count)
    image.draw(400,300)
    update_canvas()
    pass




