from pico2d import *



class Stage:
    def __init__(self):
        self.image = load_image('Texture/map/map2.png')
        self.canvas_width = get_canvas_width()
        self.canvas_height = get_canvas_height()
        self.w = self.image.w
        self.h = self.image.h

    def set_center_object(self, boy):
        self.center_object = boy
        pass

    def draw(self):
        self.image.clip_draw_to_origin(self.left,self.down,self.canvas_width,self.canvas_height,0,0)

    def update(self, frame_time):
        self.left = clamp(0, int(self.center_object.x) - self.canvas_width//2, self.w - self.canvas_width)
        self.down = clamp(0, int(self.center_object.y) - self.canvas_height//2, self.h - self.canvas_height)

    def handle_event(self, event):
        pass




class Hurdle:

    def __init__(self):
        self.x, self.y = 1110, 450

        self.image = load_image('Texture/map/hurdle.png')

        self.canvas_width = get_canvas_width()
        self.canvas_height = get_canvas_height()

    def update(self, frame_time, background):
        self.left = self.x - background.left
        self.down = self.y - background.down
        pass

    def draw(self):
        self.image.draw(self.left, self.down)


    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return self.x - 10, self.y - 10, self.x + 10, self.y + 10

    def collide(a, b):
        # fill here
        left_a, bottom_a, right_a, top_a = a.get_bb()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_a > right_b : return False
        if right_a < left_b : return False
        if top_a < bottom_b : return False
        if bottom_a > top_b : return False

        return True
        pass
