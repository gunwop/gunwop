from Import import *
from pico2d import *
import math
import random

class Boss:
    read = None
    PIXEL_PER_METER = (10.0 / 0.2)           # 10 pixel 30 cm
    RUN_SPEED_KMPH = 2                   # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION

    def __init__(self):
        self.x = 1000
        self.y = 1200
        self.left = 0.0
        self.down = 0.0
        self.frame = 0
        self.ilast = 0
        self.total = 0.0
        self.damagecheck = False
        self.state = BOSSSWING_STATE       #상태
        self.dirsheet = STATE_DOWN #방향
        self.maxHp = 200.0
        self.nowHp = self.maxHp
        self.firstpattern = True
        self.dircheck = False
        self.pleft  = 0
        self.pdown = 0
        self.dis =0
        self.staytime = 0.0
    def load_Image(self):
        if Boss.read == None:
            self.boss_down = load_image('Texture/bossdown.png')
            self.boss_ld = load_image('Texture/bossleftdown.png')
            self.boss_left = load_image('Texture/bossleft.png')
            self.boss_lu = load_image('Texture/bossleftup.png')
            self.boss_rd = load_image('Texture/bossrightdown.png')
            self.boss_right = load_image('Texture/bossright.png')
            self.boss_ru = load_image('Texture/bossrightup.png')
            self.boss_up = load_image('Texture/bossup.png')
            self.hpgage = load_image('Texture/hpgage.png')

            self.read = {STATE_DOWN : self.boss_down, STATE_LD : self.boss_ld,
                         STATE_LEFT : self.boss_left, STATE_LU : self.boss_lu,
                         STATE_RD : self.boss_rd, STATE_RIGHT : self.boss_right,
                         STATE_RU : self.boss_ru, STATE_UP : self.boss_up}

    def update(self,frame_time,background,player):
        self.left = self.x - background.left
        self.down = self.y - background.down
        self.SetMotion()
        self.FrameMove(frame_time)
        self.AI(frame_time,player)


    def FrameMove(self, frame_time):
        if(self.state == BOSSWALK_STATE): #걷기상태
                Boss.TIME_PER_ACTION = 1.0
                Boss.ACTION_PER_TIME = 1.0 / Boss.TIME_PER_ACTION
        else:
            Boss.TIME_PER_ACTION = 0.5
            Boss.ACTION_PER_TIME = 1.0 / Boss.TIME_PER_ACTION

        self.total += self.ilast * Boss.ACTION_PER_TIME * frame_time
        self.frame = int(self.total) % self.ilast
        #distance = self.RUN_SPEED_PPS * frame_time

    def draw(self):
        self.read[self.dirsheet].clip_draw(self.frame * 256,  self.state* 256, 256, 256, self.left, self.down)
        self.hpgage.clip_draw(0,0, int(self.nowHp) , 5, (self.left + int(self.nowHp/2)) - 100 , self.down - 140)
        self.draw_bb()

    def SetMotion(self):
        if(self.state == BOSSSTAND_STATE):
            self.ilast = 4

        if(self.state == BOSSWALK_STATE):
            self.ilast = 8

        if(self.state == BOSSSWING_STATE):
            self.ilast = 4

        if(self.state == BOSSDEFENCE_STATE):
            self.ilast = 2

        if(self.state == BOSSDAMAGE_STATE):
            self.damagecheck = True
            self.ilast = 2

        if(self.state == BOSSDEATH_STATE and self.damagecheck == False):
            self.ilast = 6

    def DirMove(self, frame_time):

        self.distance = self.RUN_SPEED_PPS *frame_time
        if(self.state == BOSSWALK_STATE):
            if(self.dirsheet == STATE_LEFT):
                self.x -= self.distance

            elif(self.dirsheet == STATE_RIGHT):
                self.x +=self.distance

            elif(self.dirsheet == STATE_UP):
                self.y +=self.distance

            elif(self.dirsheet == STATE_DOWN):
                self.y -=self.distance

            elif(self.dirsheet == STATE_LU):
                self.x -=self.distance
                self.y +=self.distance

            elif(self.dirsheet == STATE_LD):
                self.x -=self.distance
                self.y -=self.distance

            elif(self.dirsheet == STATE_RU):
                self.x +=self.distance
                self.y +=self.distance

            elif(self.dirsheet == STATE_RD):
                self.x +=self.distance
                self.y -=self.distance

    def AI(self, frame_time, player):
        if self.firstpattern == True:
            self.dirsheet = STATE_DOWN
            self.state = BOSSWALK_STATE
            self.DirMove(frame_time)
            if(self.y <= 520):
                self.firstpattern = False
                self.dirsheet = STATE_LEFT
                self.state = BOSSSTAND_STATE
                self.dircheck = True

        if(self.firstpattern == False):
            if(self.dircheck == True):
                self.SetDir(player)
                self.pleft = player.x
                self.pdown = player.y
                self.dircheck = False

            else:
                if(self.collide(player)):
                    self.state = BOSSSWING_STATE

                else:
                    self.state = BOSSWALK_STATE
                    self.Move(frame_time)
                    if(self.dis <= 5):
                        self.state = BOSSSTAND_STATE
                        self.staytime += frame_time
                        if(self.staytime >= 2):
                            self.staytime = 0.0
                            self.dircheck = True


    def Move(self,frame_time):
        if(self.state == BOSSWALK_STATE):
            Boss.PIXEL_PER_METER = (10.0 / 0.2)           # 10 pixel 30 cm
            Boss.RUN_SPEED_KMPH = 15                   # Km / Hour
            Boss.RUN_SPEED_MPM = (Boss.RUN_SPEED_KMPH * 1000.0 / 60.0)
            Boss.RUN_SPEED_MPS = (Boss.RUN_SPEED_MPM / 60.0)
            Boss.RUN_SPEED_PPS = (Boss.RUN_SPEED_MPS * Boss.PIXEL_PER_METER)

            self.distance = Boss.RUN_SPEED_PPS *frame_time
            self.vx = (self.pleft) - self.x
            self.vy = (self.pdown) - self.y
            self.dis = math.sqrt(math.pow(self.vx, 2) + math.pow(self.vy, 2))

            if(self.dis == 0):
                self.danx = 0
                self.dany = 0

            else:
                self.danx = self.vx/self.dis
                self.dany = self.vy/self.dis

            self.x += self.danx*self.distance
            self.y += self.dany*self.distance



    def SetDir(self, player):
            self.vx = (player.left) - self.left
            self.vy = (player.down) - self.down
            self.dis = math.sqrt(math.pow(self.vx, 2) + math.pow(self.vy, 2))

            if(self.dis == 0):
                self.danx = 0
                self.dany = 0

            else:
                self.danx = self.vx/self.dis
                self.dany = self.vy/self.dis

            if(self.danx > 0):
                self.outox = 1
                self.outoy = 0
                self.naejuk = self.outox * self.danx + self.outoy * self.dany

                if(self.dany > 0):
                    if(self.naejuk > 0.92):
                        self.dirsheet = STATE_RIGHT
                    elif(self.naejuk >= 0.5 and self.naejuk <=0.92):
                        self.dirsheet = STATE_RU
                    elif(self.naejuk < 0.5):
                        self.dirsheet = STATE_UP

                elif(self.dany < 0):
                    if(self.naejuk > 0.92):
                        self.dirsheet = STATE_RIGHT
                    elif(self.naejuk >= 0.5 and self.naejuk <=0.92):
                        self.dirsheet = STATE_RD
                    elif(self.naejuk < 0.5):
                        self.dirsheet = STATE_DOWN

            elif(self.danx < 0):
                self.outox = -1
                self.outoy = 0
                self.naejuk = self.outox * self.danx + self.outoy * self.dany

                if(self.dany > 0):
                    if(self.naejuk > 0.92):
                        self.dirsheet = STATE_LEFT
                    elif(self.naejuk >= 0.5 and self.naejuk <=0.92):
                        self.dirsheet = STATE_LU
                    elif(self.naejuk < 0.5):
                        self.dirsheet = STATE_UP


                elif(self.dany < 0):
                    if(self.naejuk > 0.92):
                        self.dirsheet = STATE_LEFT
                    elif(self.naejuk >= 0.5 and self.naejuk <=0.92):
                        self.dirsheet = STATE_LD
                    elif(self.naejuk < 0.5):
                        self.dirsheet = STATE_DOWN


    def collide(self, b):
        left_self, bottom_self, right_self, top_self = self.get_bb()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_self > right_b : return False
        if right_self < left_b : return False
        if top_self < bottom_b : return False
        if bottom_self > top_b : return False
        return True

    def draw_bb(self):
        draw_rectangle(*self.get_bb())
        draw_rectangle(*self.attack_bb())


    def get_bb(self):
        return self.left - 20, self.down - 100, self.left + 40, self.down


    def attack_bb(self):
        if(self.state == BOSSSWING_STATE):
            if(self.dirsheet == STATE_RIGHT and self.frame == 3):
                return self.left+50, self.down - 90, self.left + 80, self.down - 70

            elif(self.dirsheet == STATE_LEFT and self.frame == 3):
                return self.left-90, self.down - 120, self.left-50, self.down - 90

            elif(self.dirsheet == STATE_UP and self.frame == 3):
                return self.left , self.down - 30, self.left+30, self.down - 10

            elif(self.dirsheet == STATE_DOWN and self.frame == 3):
                return self.left, self.down -120, self.left+30, self.down - 90

            elif(self.dirsheet == STATE_RU and self.frame == 3):
                return self.left +50, self.down - 70, self.left +80, self.down - 50

            elif(self.dirsheet == STATE_RD and self.frame == 3):
                return self.left +50, self.down -120, self.left +70, self.down - 90

            elif(self.dirsheet == STATE_LU and self.frame == 3):
                return self.left - 70, self.down -70, self.left - 40, self.down - 50

            elif(self.dirsheet == STATE_LD and self.frame == 3):
                return self.left - 50, self.down -120, self.left -20, self.down - 90

            else:
                return self.left-4000, self.down-4000, self.left-4001, self.down-4001
        else:
            return self.left-4000, self.down-4000, self.left-4001, self.down-4001