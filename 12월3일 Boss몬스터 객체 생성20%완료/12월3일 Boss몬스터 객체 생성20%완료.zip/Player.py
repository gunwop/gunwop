from Import import *
from pico2d import *
import gameover
import math


class Player:
    read = None
    PIXEL_PER_METER = (10.0 / 0.2)           # 10 pixel 30 cm
    RUN_SPEED_KMPH = 10.0                    # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.4
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION


    PIXEL_PER_METER = 20.0           # 10 pixel 30 cm
    SKILL_KMPH = 1.0                    # Km / Hour
    SKILL_MPM = (SKILL_KMPH * 1000.0 / 60.0)
    SKILL_MPS = (SKILL_MPM / 60.0)
    SKILL_PPS = (SKILL_MPS * PIXEL_PER_METER)

    pdamage = None
    pdeadground = None
    pdie = None
    pwalk = None

    def __init__(self):
        self.x, self.y = 400, 400
        self.frame = 0
        self.ilast = 0
        self.state = STAND_STATE #player 상태
        self.dirsheet = STATE_DOWN
        self.dirleft = False
        self.dirright = False
        self.dirup = False
        self.dirdown = False
        self.checklu = False
        self.checkld = False
        self.checkru = False
        self.checkrd = False
        self.frametime = 0.0
        self.total = 0.0
        self.maxHp = 100
        self.nowHp = self.maxHp
        self.maxmana = 100
        self.nowmana = self.maxmana
        self.canvas_width = get_canvas_width()
        self.canvas_height = get_canvas_height()
        self.x_offset = 0.0
        self.y_offset = 0.0
        self.count = 1
        self.timecheck = 0.0


        if Player.pdamage ==None:
            Player.pdamage = load_wav('Sound/playerdamage.wav')
            Player.pdamage.set_volume(5)

        if Player.pdeadground ==None:
            Player.pdeadground = load_wav('Sound/playerdead.wav')
            Player.pdeadground.set_volume(2)

        if Player.pdie ==None:
            Player.pdie = load_wav('Sound/playerdie.wav')
            Player.pdie.set_volume(2)

        if Player.pwalk ==None:
            Player.pwalk = load_wav('Sound/playerwalk.wav')
            Player.pwalk.set_volume(2)


    def load_Image(self):
        if Player.read == None:
             self.player_down = load_image('Texture/Player_DOWN.png') #아래방향
             self.player_ld = load_image('Texture/Player_LD.png') #왼쪽아래
             self.player_left = load_image('Texture/Player_LEFT.png') #왼쪽
             self.player_lu = load_image('Texture/Player_LU.png') #왼쪽위
             self.player_rd = load_image('Texture/Player_RD.png') #오른쪽아래
             self.player_right = load_image('Texture/Player_RIGHT.png') #오른쪽
             self.player_ru = load_image('Texture/Player_RU.png') #오른쪽 위
             self.player_up = load_image('Texture/Player_UP.png') #위


             self.read = {STATE_DOWN : self.player_down, STATE_LD : self.player_ld,
                            STATE_LEFT : self.player_left, STATE_LU : self.player_lu,
                            STATE_RD : self.player_rd, STATE_RIGHT : self.player_right,
                            STATE_RU : self.player_ru, STATE_UP : self.player_up}

    def update(self,frame_time):
        self.SetMotion()
        self.FrameMove(frame_time)
        if(self.maxmana < self.nowmana):
            self.nowmana -= self.SKILL_PPS * frame_time
        else:
            self.nowmana = self.maxmana

        self.x = clamp(20, self.x, self.bg.w-20)
        self.y = clamp(40, self.y, self.bg.h-40)

        if(self.state == DAMAGE_STATE):
            self.count = (self.count+1)%250+1
        else:
            self.count = 1

        self.left = self.canvas_width // 2 + self.x_offset
        self.down = self.canvas_height // 2 + self.y_offset




    def draw(self,frame_time):
        self.x_left_offset = min(0,self.x - self.canvas_width //2);
        self.x_right_offset = max(0,self.x - self.bg.w + self.canvas_width //2);
        self.x_offset = self.x_left_offset + self.x_right_offset;

        self.y_down_offset = min(0,self.y - self.canvas_height //2);
        self.y_top_offset = max(0,self.y - self.bg.h + self.canvas_height //2);
        self.y_offset = self.y_down_offset + self.y_top_offset;

        self.read[self.dirsheet].opacify(self.count)
        self.read[self.dirsheet].clip_draw(self.frame * 200, self.state*200, 200, 200,self.left,
                                          self.down)
        self.draw_bb()

    def SetMotion(self):
        if(self.state == STAND_STATE): #대기상태
            self.ilast = 4

        if(self.state == WALK_STATE): #걷기상태
            self.ilast = 6

        if(self.state == ATTACK_STATE): #공격상태
            self. ilast = 6

        if(self.state == DAMAGE_STATE): #피격상태
            self.ilast = 2

        if(self.state == DEATH_STATE): #사망상태
            self.ilast = 4


    def FrameMove(self,frame_time):
        if(self.state == ATTACK_STATE):
            Player.TIME_PER_ACTION = 0.2
        else:
            Player.TIME_PER_ACTION = 0.4
            Player.ACTION_PER_TIME = 1.0 / Player.TIME_PER_ACTION

        if(self.state == DEATH_STATE and self.frame >= self.ilast -1):
            self.frame = self.ilast -1
            self.timecheck += frame_time

            if(self.timecheck >= 1):
                game_framework.push_state(gameover)

        else:
            self.total += self.ilast * Player.ACTION_PER_TIME * frame_time
            self.frame = int(self.total) % self.ilast


        self.distance = self.RUN_SPEED_PPS *frame_time



        if(self.state == WALK_STATE): #걷기상태

            if self.dirleft == True:
                    self.x -= self.distance


            if self.dirright == True:
                    self.x += self.distance

            if self.dirup == True:
                    self.y += self.distance


            if self.dirdown == True:
                    self.y -= self.distance



        if(self.nowHp >= 404): #게임 실패시 트리거
            self.state =DEATH_STATE
            self.pdie.play(1)
            self.pdeadground.play(1)




    def handle_event(self, event, frame_time):
        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT): #왼쪽keydown
            self.dirsheet = STATE_LEFT
            self.state = WALK_STATE
            self.dirleft = True
            self.checklu = False
            self.checkld = False
            self.checkru = False
            self.checkrd = False
            if self.dirleft == True and self.dirup == True:
                self.dirsheet = STATE_LU
                self.checklu = True
            if self.dirleft == True and self.dirdown == True:
                self.dirsheet = STATE_LD
                self.checkld = True

        if(event.type, event.key) == (SDL_KEYUP, SDLK_LEFT): #왼쪽keyup
            self.dirleft = False

            if(self.dirleft == False and self.dirright == False and self.dirup == False and self.dirdown == False):
                self.state = STAND_STATE
                self.dirsheet = STATE_LEFT

            if self.dirleft == False and self.dirup == False and self.checklu == True:
                self.dirsheet = STATE_LU

            if self.dirleft == False and self.dirdown == False and self.checkld == True:
                self.dirsheet = STATE_LD

            elif self.dirright == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_RIGHT

            elif self.dirup == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_UP

            elif self.dirdown == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_DOWN

        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT): #오른쪽
            self.dirsheet = STATE_RIGHT
            self.state = WALK_STATE
            self.dirright = True
            self.checklu = False
            self.checkld = False
            self.checkru = False
            self.checkrd = False
            if self.dirright == True and self.dirup == True:
                self.dirsheet = STATE_RU
                self.checkru = True
            if self.dirright == True and self.dirdown == True:
                self.dirsheet = STATE_RD
                self.checkrd = True


        if(event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT): #오른쪽 up
            self.dirright = False

            if(self.dirleft == False and self.dirright == False and self.dirup == False and self.dirdown == False):
                self.state = STAND_STATE
                self.dirsheet = STATE_RIGHT

            if(self.dirright == False and self.dirup == False and self.checkru == True):
                self.dirsheet = STATE_RU

            if(self.dirright == False and self.dirdown == False and self.checkrd == True):
                self.dirsheet = STATE_RD

            elif self.dirleft == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_LEFT
            elif self.dirup == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_UP
            elif self.dirdown == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_DOWN

        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_UP): # 위쪽
            self.dirsheet = STATE_UP
            self.state = WALK_STATE
            self.dirup = True
            self.checklu = False
            self.checkld = False
            self.checkru = False
            self.checkrd = False
            if self.dirup == True and self.dirleft == True:
                self.dirsheet = STATE_LU
                self.checklu = True
            if self.dirup == True and self.dirright == True:
                self.dirsheet = STATE_RU
                self.checkru = True


        if(event.type, event.key) == (SDL_KEYUP, SDLK_UP): # 위쪽 up
            self.dirup = False

            if(self.dirleft == False and self.dirright == False and self.dirup == False and self.dirdown == False):
                self.state = STAND_STATE
                self.dirsheet = STATE_UP

            if(self.dirright == False and self.dirup == False and self.checkru == True):
                self.dirsheet = STATE_RU

            if(self.dirleft == False and self.dirup == False and self.checklu == True):
                self.dirsheet = STATE_LU

            elif self.dirleft == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_LEFT

            elif self.dirright == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_RIGHT

            elif self.dirdown == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_DOWN

        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_DOWN): #아래쪽
            self.dirsheet = STATE_DOWN
            self.state = WALK_STATE
            self.dirdown = True
            self.checklu = False
            self.checkld = False
            self.checkru = False
            self.checkrd = False
            if self.dirdown == True and self.dirleft == True:
                self.dirsheet = STATE_LD
                self.checkld = True
            if self.dirdown == True and self.dirright == True:
                self.dirsheet = STATE_RD
                self.checkrd = True


        if(event.type, event.key) == (SDL_KEYUP, SDLK_DOWN): # 아래쪽 up
            self.dirdown = False

            if(self.dirleft == False and self.dirright == False and self.dirup == False and self.dirdown == False):
                self.state = STAND_STATE
                self.dirsheet = STATE_DOWN

            if self.dirleft == False and self.dirdown == False and self.checkld == True:
                self.dirsheet = STATE_LD

            if(self.dirright == False and self.dirup == False and self.checkrd == True):
                self.dirsheet = STATE_RD

            elif self.dirleft == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_LEFT
            elif self.dirright == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_RIGHT
            elif self.dirup == True:
                self.state = WALK_STATE
                self.dirsheet = STATE_UP

        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_a):
            if(self.state != DAMAGE_STATE):
                self.checklu = False
                self.checkld = False
                self.checkru = False
                self.checkrd = False
                self.state = ATTACK_STATE

        if(event.type, event.key) == (SDL_KEYUP, SDLK_a):
            if(self.dirleft == False and self.dirright == False and self.dirup == False and self.dirdown == False):
                self.state = STAND_STATE
            else:
                self.state = WALK_STATE

        #if(event.type, event.key) == (SDL_KEYDOWN, SDLK_s):
            #self.nowHp += 5  #만약에 nowHp가 404가 되면 체력이 0이 된다.
            #self.nowmana += 5  #만약에 373이 되면 마나가 0이된다.

    def set_background(self, bg):
        self.bg = bg

    def get_bb(self):
        return (self.left-10), (self.down-30),\
               (self.left+20), (self.down+40)


    def collide(self, b):
        left_self, bottom_self, right_self, top_self = self.get_bb()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_self < right_b : return False
        if right_self > left_b : return False
        if top_self < bottom_b : return False
        if bottom_self > top_b : return False

        return True

    def draw_bb(self):
        draw_rectangle(*self.get_bb())



class Skill:
    read = None
    pskill = None
    def __init__(self):
        self.x = 0
        self.y = 0
        self.frame = 0
        self.step = 0
        self.check = False
        self.mana = 10
        self.dir = 10
        self.cool = 0
        self.coolcheck = False
        if Skill.read == None:
            Skill.image = load_image('Texture/skill.png')

        if Skill.pskill ==None:
            Skill.pskill = load_wav('Sound/skill.wav')
            Skill.pskill.set_volume(5)

    def draw(self):
        if(self.check == True):
            self.image.clip_draw(self.frame *120 ,self.step * 160, 120, 160, self.x, self.y)
        self.draw_bb()


    def update(self):
        if(self.check == True):

            self.frame = int(self.frame + 1) %10

            if(self.frame == 9):
                self.step +=1

            if(self.frame >= 5 and self.step >= 9):
                self.check = False
                self.frame = 0
                self.step = 0
                self.dir = 10
                self.coolcheck = True
                self.x = 0
                self.y = 0

        if(self.coolcheck == True):
            self.pskill.play(1)
            self.cool += 1

        if(self.cool >= 100):
            self.cool = 0
            self.coolcheck = False


    def handle_event(self, event,player):
        if(event.type, event.key) == (SDL_KEYDOWN,SDLK_a):
            if(player.state == ATTACK_STATE):
                if(player.nowmana <= 363 and self.coolcheck == False):
                    player.nowmana += self.mana
                    self.check = True
                    self.dir = player.dirsheet
                    if(self.dir == STATE_UP):
                        self.x = player.canvas_width // 2 + player.x_offset
                        self.y = player.canvas_height // 2 + player.y_offset + 120

                    elif(self.dir == STATE_RU):
                        self.x = player.canvas_width // 2 + player.x_offset +100
                        self.y = player.canvas_height // 2 + player.y_offset + 100

                    elif(self.dir == STATE_LU):
                        self.x = player.canvas_width // 2 + player.x_offset -100
                        self.y = player.canvas_height // 2 + player.y_offset + 100

                    elif(self.dir == STATE_LEFT):
                        self.x = player.canvas_width // 2 + player.x_offset -100
                        self.y = player.canvas_height // 2 + player.y_offset + 30
                    elif(self.dir == STATE_RIGHT):
                        self.x =  player.canvas_width // 2 + player.x_offset +100
                        self.y =  player.canvas_height // 2 + player.y_offset + 30

                    elif(self.dir == STATE_DOWN):
                        self.x =  player.canvas_width // 2 + player.x_offset
                        self.y =  player.canvas_height // 2 + player.y_offset -100

                    elif(self.dir == STATE_LD):
                        self.x =  player.canvas_width // 2 + player.x_offset  -90
                        self.y =  player.canvas_height // 2 + player.y_offset -50

                    elif(self.dir == STATE_RD):
                        self.x = player.canvas_width // 2 + player.x_offset +90
                        self.y = player.canvas_height // 2 + player.y_offset -50

    def get_bb(self):
        return self.x - 30, self.y - 60, self.x + 20, self.y - 30

    def draw_bb(self):
        draw_rectangle(*self.get_bb())