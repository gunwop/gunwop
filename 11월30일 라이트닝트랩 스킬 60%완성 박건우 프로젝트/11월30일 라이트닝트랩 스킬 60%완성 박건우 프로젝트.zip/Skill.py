from Import import *
from pico2d import *
import random

class LightingSkillList:
    def __init__(self):
        self.skilllist = []
        self.length = 0
        self.index = 0
        self.light = LightingSkill()

    def draw(self,frame_time):
        for i in range(0,self.length):
            self.skilllist[i].draw(frame_time)

    def update(self,frame_time,player):
        for i in range(0,self.length):
            self.skilllist[i].update(frame_time,player)

    def handle_event(self, event, frame_time):
        if(event.type, event.key) == (SDL_KEYDOWN,SDLK_s):
            self.skilllist.append(self.light)
            self.length+=1
            print("길이",self.length)



class LightingSkill:
    read = None
    TIME_PER_ACTION = 0.4
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION

    def __init__(self):
        self.x = 0
        self.y = 0
        self.frame = 0
        self.mana = 20
        self.ilast = 10
        self.total = 0.0
        if LightingSkill.read == None:
            LightingSkill.image = load_image('Texture/Effect/light.png')


    def draw(self,frame_time):
            self.image.clip_draw(self.frame *51,0, 51, 59, self.x, self.y)


    def update(self,frame_time,player):
        LightingSkill.TIME_PER_ACTION = 0.4
        LightingSkill.ACTION_PER_TIME = 1.0 / LightingSkill.TIME_PER_ACTION

        self.total += self.ilast * LightingSkill.ACTION_PER_TIME * frame_time
        self.frame = int(self.total) % self.ilast
        self.x = player.x
        self.y = player.x
    def get_bb(self):
        return self.x - 30, self.y - 60, self.x + 20, self.y - 30

    def draw_bb(self):
        draw_rectangle(*self.get_bb())
