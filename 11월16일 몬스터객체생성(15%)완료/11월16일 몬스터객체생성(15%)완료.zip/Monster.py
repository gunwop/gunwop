from Import import *
from pico2d import *

class Monster:
    PIXEL_PER_METER = (10.0 / 0.3)           # 10 pixel 30 cm
    RUN_SPEED_KMPH = 20.0                    # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    image = None

    LEFT_DOWN, DOWN, RIGHT_DOWN, RIGHT, RIGHT_UP, UP, LEFT_UP, LEFT = 0, 1, 2, 3, 4, 5, 6, 7



    def __init__(self):
        self.x, self.y = 500, 300
        self.frame = 0
        self.ilast = 0
        self.state = STAND_STATE
        self.dir = self.DOWN
        if Monster.image == None:
            self.image = load_image('Texture/monster/horse_paint.png')


    def update(self):
        self.frame = (self.frame + 1)%24


    def draw(self):
        self.image.clip_draw(self.frame * 128, self.dir * 128, 128, 128, self.x, self.y)





