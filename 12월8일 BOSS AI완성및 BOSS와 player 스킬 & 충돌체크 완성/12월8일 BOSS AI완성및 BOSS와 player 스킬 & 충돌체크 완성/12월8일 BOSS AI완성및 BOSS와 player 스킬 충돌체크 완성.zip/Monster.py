from Import import *
from pico2d import *
import math
import random

class Monster:
    read = None
    PIXEL_PER_METER = (10.0 / 0.1)           # 10 pixel 30 cm
    RUN_SPEED_KMPH = random.randint(1, 2)                    # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION

    damage = None
    walk = None
    dead = None

    def __init__(self):
        self.x, self.y = random.randint(100, 1000), random.randint(200, 500)
        self.frame = 0
        self.ilast = 0
        self.state = MWALK_STATE #상태
        self.dirsheet = STATE_RIGHT #방향
        self.frametime = 0.0
        self.total = 0.0
        self.maxHp = 70.0
        self.nowHp = self.maxHp
        self.timecheck = 0.0
        self.deathcheck = False
        self.left = 0.0
        self.down = 0.0
        self.damagecheck = False
        self.damagetime = 0.0
        if Monster.walk ==None:
            Monster.walk = load_wav('Sound/horsewalking.wav')
            Monster.walk.set_volume(1);

        if Monster.damage == None:
            Monster.damage = load_wav('Sound/horsedamage.wav')
            Monster.damage.set_volume(5)

        if Monster.dead == None:
            Monster.dead = load_wav('Sound/horsedead.wav')
            Monster.dead.set_volume(5)



    def load_Image(self):
        if Monster.read == None:
            self.monster_down = load_image('Texture/down.png')
            self.monster_ld = load_image('Texture/leftdown.png')
            self.monster_left = load_image('Texture/left.png')
            self.monster_lu = load_image('Texture/leftup.png')
            self.monster_rd = load_image('Texture/rightdown.png')
            self.monster_right = load_image('Texture/right.png')
            self.monster_ru = load_image('Texture/rightup.png')
            self.monster_up = load_image('Texture/up.png')
            self.hpgage = load_image('Texture/hpgage.png')

            self.read = {STATE_DOWN : self.monster_down, STATE_LD : self.monster_ld,
                         STATE_LEFT : self.monster_left, STATE_LU : self.monster_lu,
                         STATE_RD : self.monster_rd, STATE_RIGHT : self.monster_right,
                         STATE_RU : self.monster_ru, STATE_UP : self.monster_up}


    def update(self, player, frame_time, background, skill):
        self.left = self.x - background.left
        self.down = self.y - background.down
        self.SetDir(player)
        self.SetMotion()
        self.DirMove(frame_time)
        self.FrameMove(frame_time)
        self.changestate(player, skill)
        self.Attack(player)
        self.get_bb()



    def draw(self, frame_time):
        self.read[self.dirsheet].clip_draw(self.frame * 128,  self.state* 128, 128, 128, self.left, self.down)
        self.hpgage.clip_draw(0,0, int(self.nowHp) , 5, (self.left + int(self.nowHp/2)) - 30 , self.down - 60)
        self.draw_bb()

    def SetDir(self, player):
        if(self.state != MDEATH_STATE ):
            self.vx = (player.left) - self.left
            self.vy = (player.down) - self.down
            self.dis = math.sqrt(math.pow(self.vx, 2) + math.pow(self.vy, 2))

            if(self.dis == 0):
                self.danx = 0
                self.dany = 0

            else:
                self.danx = self.vx/self.dis
                self.dany = self.vy/self.dis

            if(self.danx > 0):
                self.outox = 1
                self.outoy = 0
                self.naejuk = self.outox * self.danx + self.outoy * self.dany

                if(self.dany > 0):
                    if(self.naejuk > 0.92):
                        self.dirsheet = STATE_RIGHT
                    elif(self.naejuk >= 0.5 and self.naejuk <=0.9):
                        self.dirsheet = STATE_RU
                    elif(self.naejuk < 0.5):
                        self.dirsheet = STATE_UP

                elif(self.dany < 0):
                    if(self.naejuk > 0.92):
                        self.dirsheet = STATE_RIGHT
                    elif(self.naejuk >= 0.5 and self.naejuk <=0.9):
                        self.dirsheet = STATE_RD
                    elif(self.naejuk < 0.5):
                        self.dirsheet = STATE_DOWN

            elif(self.danx < 0):
                self.outox = -1
                self.outoy = 0
                self.naejuk = self.outox * self.danx + self.outoy * self.dany

                if(self.dany > 0):
                    if(self.naejuk > 0.92):
                        self.dirsheet = STATE_LEFT
                    elif(self.naejuk >= 0.5 and self.naejuk <=0.9):
                        self.dirsheet = STATE_LU
                    elif(self.naejuk < 0.5):
                        self.dirsheet = STATE_UP


                elif(self.dany < 0):
                    if(self.naejuk > 0.92):
                        self.dirsheet = STATE_LEFT
                    elif(self.naejuk >= 0.5 and self.naejuk <=0.9):
                        self.dirsheet = STATE_LD
                    elif(self.naejuk < 0.5):
                        self.dirsheet = STATE_DOWN


    def SetMotion(self):
        if(self.state == MSTAND_STATE):
            self.ilast = 4

        if(self.state == MWALK_STATE):
            self.ilast = 8

        if(self.state == MATTACK_STATE):
            self.ilast = 5

        if(self.state == MDAMAGE_STATE):
            self.ilast = 3

        if(self.state == MDEATH_STATE):
            self.ilast = 7


    def FrameMove(self, frame_time):
        Monster.TIME_PER_ACTION = 0.5
        Monster.ACTION_PER_TIME = 1.0 / Monster.TIME_PER_ACTION

        if(self.state == MDEATH_STATE and self.frame >= self.ilast - 1):
            self.deathcheck =True
            self.frame = self.ilast -1
            self.timecheck += frame_time

        else:
            self.total += self.ilast * Monster.ACTION_PER_TIME * frame_time
            self.frame = int(self.total) % self.ilast
        #distance = self.RUN_SPEED_PPS * frame_time

    def DirMove(self, frame_time):
        distance = self.RUN_SPEED_PPS *frame_time
        if(self.state == MWALK_STATE):
            self.walk.play(1)
            if(self.dirsheet == STATE_LEFT):
                self.x -=distance
            elif(self.dirsheet == STATE_RIGHT):
                self.x +=distance
            elif(self.dirsheet == STATE_UP):
                self.y +=distance
            elif(self.dirsheet == STATE_DOWN):
                self.y -=distance
            elif(self.dirsheet == STATE_LU):
                self.x -=distance
                self.y +=distance
            elif(self.dirsheet == STATE_LD):
                self.x -=distance
                self.y -=distance
            elif(self.dirsheet == STATE_RU):
                self.x +=distance
                self.y +=distance
            elif(self.dirsheet == STATE_RD):
                self.x +=distance
                self.y -=distance

    def get_bb(self):
        if(self.dirsheet == STATE_UP or self.dirsheet == STATE_DOWN):
            return self.left - 20, self.down - 40, self.left + 10, self.down + 10

        else:
            return self.left - 30, self.down - 50, self.left + 20, self.down - 10


    def attack_bb(self):
        if(self.state == MATTACK_STATE):
            if(self.dirsheet == STATE_RIGHT and self.frame == 3):
                return self.left+15, self.down+10, self.left + 25, self.down+20

            elif(self.dirsheet == STATE_LEFT and self.frame == 3):
                return self.left-35, self.down + 5, self.left-25, self.down + 15

            elif(self.dirsheet == STATE_UP and self.frame == 3):
                return self.left - 10, self.down + 30, self.left, self.down + 40
            ##
            elif(self.dirsheet == STATE_DOWN and self.frame == 3):
                return self.left - 10, self.down -40, self.left, self.down - 30

            elif(self.dirsheet == STATE_RU and self.frame == 3):
                return self.left + 15, self.down + 30, self.left +25, self.down + 40

            elif(self.dirsheet == STATE_RD and self.frame == 3):
                return self.left +15, self.down -30, self.left +25, self.down - 20
#####################
            elif(self.dirsheet == STATE_LU and self.frame == 3):
                return self.left - 25, self.down +15, self.left - 15, self.down + 25

            elif(self.dirsheet == STATE_LD and self.frame == 3):
                return self.left - 35, self.down -50, self.left -25, self.down - 40

            else:
                return self.left-2000, self.down-2000, self.left-2001, self.down-2001
        else:
            return self.left-2000, self.down-2000, self.left-2001, self.down-2001

    def attackcollide(self, b):
        left_self, bottom_self, right_self, top_self = self.attack_bb()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_self > right_b : return False
        if right_self < left_b : return False
        if top_self < bottom_b : return False
        if bottom_self > top_b : return False
        return True

    def Attack(self, player):
        if(self.state == MATTACK_STATE):
            if self.attackcollide(player):
                player.nowHp += 0.2
                if(player.state != DEATH_STATE):
                    player.state =DAMAGE_STATE
                    player.pdamage.play(1)


    def collide(self, b):
        left_self, bottom_self, right_self, top_self = self.get_bb()
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_self > right_b : return False
        if right_self < left_b : return False
        if top_self < bottom_b : return False
        if bottom_self > top_b : return False
        return True



    def draw_bb(self):
        draw_rectangle(*self.get_bb())
        draw_rectangle(*self.attack_bb())

    def changestate(self, player,skill):
        if (self.collide(player)):
            self.state = MATTACK_STATE
########################################################################################################
        elif(self.collide(skill) or self.damagecheck == True):
            if(self.deathcheck == False):
                self.damage.play(1)
                if(self.damagecheck == True):
                    self.nowHp -=0.15
                else:
                    self.nowHp -=0.05
                self.state = MDAMAGE_STATE
                self.frame =0
                if(self.damagecheck == True):
                    self.damagetime += 1
                    if(self.damagetime >= 100):
                        self.damagetime = 0.0
                        self.damagecheck = False
        else:
            self.state = MWALK_STATE


        if(self.nowHp <= 0):
            self.state = MDEATH_STATE
            self.dead.play(1)


